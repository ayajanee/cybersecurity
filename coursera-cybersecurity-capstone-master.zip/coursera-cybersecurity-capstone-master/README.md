# Super secure, much safe, so chat

Students:
  Elias Rabl, Andreas Lindlbauer


The project is hosted at: http://cs-capstone-chat.herokuapp.com/